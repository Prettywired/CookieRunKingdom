import java.util.Stack;

public class Ranks {
    HeapName[] max;
    String[] r = {"ancient", "legendary", "superEpic", "epic", "rare", "common"};

    public Ranks() {
        max = new HeapName[6];
        for (int i = 0; i < max.length; i++) {
            max[i] = new HeapName(r[i]);
        }

    }

    public void insert(String s, Stack<String> stk) {
        int i = 0;
        while (!Character.isWhitespace(s.charAt(i))) {
            i++;
        }
        String sub = s.substring(0, i);
        stk.push(sub);
        int f = search(sub);

        max[f].m.insert(s.substring(i+1), stk);
    }
public boolean isEmptyRank(){
    int i = 0;
    boolean empty=true;
    while (i < max.length) {
        if (!max[i].m.isEmpty()) {
            empty=false;
            break;
        }
        i++;
    }
    return empty;
}
    public int search(String v) {
        int i = 0;
        while (i < max.length && !max[i].rank.equals(v)) {
            i++;
        }

        return i;
    }

    public Characters find() {
        int s = 0;
        Characters e=null;
        for (int i = 0; i < max.length; i++) {


            if (max[i].m.f!=-1) {


                s = i;
           e= max[s].m.delete();
                break;
            }
        }
        return e;
}}

