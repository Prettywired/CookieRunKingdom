public class RankName {
    String power;
    Ranks rank;

    RankName(String pow) {
        power = pow;
        rank = new Ranks();
    }

}
