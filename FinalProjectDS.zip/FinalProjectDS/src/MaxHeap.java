import java.util.Stack;

public class MaxHeap {
    Characters[] array;
    int f;

    MaxHeap() {
        f = -1;
        array = new Characters[20];
    }

    public int Parent(int p) {
        return (p - 1) / 2;
    }

    public int LChild(int p) {
        return 2 * p + 1;
    }

    public int RChild(int p) {
        return 2 * p + 2;
    }


    public void insert(String key, Stack<String> stk) {
        int i = 0;

        while (!Character.isWhitespace(key.charAt(i))) {
            i++;
        }
        String s = key.substring(0, i);
        stk.push(s);
        stk.push(key.substring(i+1));

        Characters c = createChar(stk);

        f = f + 1;
        array[f] = c;
        heap();
    }

    public void heap() {
        if (f != -1) {
            int p = Parent(f);

            while (p >= 0 && array[f].level.compareTo(array[p].level) > 0) {

                swap(f, p);
                f = p;
                p = Parent(p);

            }
        }
    }

    public Characters createChar(Stack<String> stk) {
        String name = stk.pop();
        String level = stk.pop();
        String rank = stk.pop();
        String power = stk.pop();
        return new Characters(name, level, rank, power);
    }

    public void ReHeap() {
        int i = 0;
        while (LChild(i) <= f && RChild(i) <= f) {
            if (array[LChild(i)].level.compareToIgnoreCase(array[RChild(i)].level) > 0) {
                swap(i, LChild(i));
                i = LChild(i);
            } else {
                swap(i, RChild(i));
                i = RChild(i);
            }
        }
    }


    public Characters delete() {
if(isEmpty()){
    return null;
}
else{
        Characters temp = array[0];
        if(f==0){
            f=-1;
            return temp;
        }
        else{
        swap(0, f);

        array[f] = null;
        f = f - 1;
        ReHeap();
        return temp;}
    }
    }

    public void swap(int i, int j) {
        Characters temp = array[j];
        array[j] = array[i];
        array[i] = temp;
    }


    public boolean isEmpty() {
        if (f == -1)
            return true;
        else return false;
    }
}


