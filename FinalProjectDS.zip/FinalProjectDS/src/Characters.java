public class Characters {

    String name;
    String rank;
    String power;
    String level;


    Characters(String name, String level, String rank, String power) {
        this.name = name;
        this.level = level;
        this.rank = rank;
        this.power = power;

    }

    @Override
    public String toString() {
        return "Characters{" +
                "name='" + name + '\'' +
                ", rank='" + rank + '\'' +
                ", power='" + power + '\'' +
                ", level=" + level +
                '}';
    }

}
