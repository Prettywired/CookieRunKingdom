public class HeapName {

    String rank;
    MaxHeap m;

    HeapName(String r) {
        rank = r;
        m = new MaxHeap();
    }

}
