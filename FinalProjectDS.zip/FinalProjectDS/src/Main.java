import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {

        //File f = new File("B:\\Downloads\\CookieRUN.txt");
File f=new File("B:\\Downloads\\b.txt");
        Game g = new Game(f);
        Characters strong=g.getStrongest("healing");
        System.out.println(strong.toString());
        Characters[] s=g.makeTeam();
        for(int i=0;i<s.length;i++){
        System.out.println(s[i].toString());}


    }
}
