import java.util.Stack;

public class HashTable {
    RankName[] powers = new RankName[12];
    String[] arr = {"charge", "defense", "healing", "magic", "ranged", "support", "ambush", "bomber"};

    HashTable() {
        for (int i = 0; i < arr.length; i++) {
            String key = arr[i];
            int hashVal = Hash(key);


            if (powers[hashVal] == null) {
                powers[hashVal] = new RankName(key);
            } else {
                for (int j = 1; j < powers.length; j++) {
                    int f=Rehash(key,j);

                    if(powers[f]==null){
                    hashVal=f;
                    break;}


                }
                powers[hashVal] = new RankName(key);
            }
            System.out.println(hashVal+" " + key);
        }
    }

    public void insert(String key) {
        Stack<String> stk = new Stack<>();
        int i = 0;
        String s = "";
        while (!Character.isWhitespace(key.charAt(i))) {

            i++;
        }

        s = key.substring(0, i);

        stk.push(s);
        int f = search(s);

        powers[f].rank.insert(key.substring(i + 1), stk);

    }
    public boolean isEmpty(){
        boolean empty=true;
        for(int i=0;i<arr.length;i++){
            int f=search(arr[i]);
            if(!powers[f].rank.isEmptyRank())
            { empty=false;
                break;

            }

        }
        return empty;
    }

    public Characters[] random() {
        Characters[] c = new Characters[5];
        if(isEmpty()){
            System.out.println("Table in empty");

        return c;}
        else{
        for (int j = 0; j < c.length; j++) {
            String w=arr[(int)(Math.random()*8)];
            int f=search(w);

            while(powers[f].rank.isEmptyRank()){
                w=arr[(int)(Math.random()*8)];
                f=search(w);
            }

            c[j] = powers[f].rank.find();
        }}

        return c;
    }

    public Characters find(String key) {
        int g = search(key);
        return powers[g].rank.find();
    }

    public int Hash(String key) {
        //compute hash value by taking mod on key's 1st alphabet and return remainder
        int hashVal = (key.charAt(0)-97) % powers.length;
        return hashVal;
    }

    public int Rehash(String key, int i) {
        //lin probing:

        return (key.charAt(0)-97 + i) % powers.length;
    }

    public int search(String key) {
        int hashVal = Hash(key);
        int i = 1;

        while (!powers[hashVal].power.equals(key)) {
            hashVal = Rehash(key, i);
            i++;
        }
        return hashVal;
    }


}

