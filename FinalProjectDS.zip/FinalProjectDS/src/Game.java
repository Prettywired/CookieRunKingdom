import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class Game {
    HashTable h;

    public Game(File f) throws FileNotFoundException {
        h = new HashTable();
        Scanner c = new Scanner(new FileReader(f));
        while (c.hasNextLine()) {

            String d = c.nextLine();
            h.insert(d);
        }

    }

    public Characters getStrongest(String pow) {
        return h.find(pow);
    }

    public Characters[] makeTeam() {
        return h.random();
    }

}
